/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazen
 */
public class BookingGUITest {
    
    public BookingGUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_book method, of class BookingGUI.
     */
    @Test
    public void testCheck_book() {
        System.out.println("check_book");
        String name = "mazin";
        String ph = "01129073567";
        int age = 22 ;
        String dname = "shaza hatem";
        int time = 4 ;
        String AM_PM = "PM";
        String selected_d = "Sunday";
        BookingGUI instance = new BookingGUI();
        boolean expResult = false;
        boolean result = instance.check_book(name, ph, age, dname, time, AM_PM, selected_d);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    
//    @Test
//    public void testCheck_book() {
//        System.out.println("check_book");
//        String name = "mazin";
//        String ph = "01129073567";
//        int age = 22 ;
//        String dname = "rasha hatem";
//        int time = 7 ;
//        String AM_PM = "PM";
//        String selected_d = "Sunday";
//        BookingGUI instance = new BookingGUI();
//        boolean expResult = true;
//        boolean result = instance.check_book(name, ph, age, dname, time, AM_PM, selected_d);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//       // fail("The test case is a prototype.");
//    }
    /**
     * Test of main method, of class BookingGUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        BookingGUI.main(args);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
