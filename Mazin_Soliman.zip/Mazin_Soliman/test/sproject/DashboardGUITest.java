/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazen
 */
public class DashboardGUITest {
    
    public DashboardGUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_count method, of class DashboardGUI.
     */
//    @Test
//    public void testCheck_count() {
//        System.out.println("check_count");
//        String SD = "Sunday";
//        DashboardGUI instance = new DashboardGUI();
//        boolean expResult = true;
//        boolean result = instance.check_count(SD);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of check_min method, of class DashboardGUI.
     */
//    @Test
//    public void testCheck_min() {
//        System.out.println("check_min");
//        String SD = "Sunday";
//        DashboardGUI instance = new DashboardGUI();
//        boolean expResult = true;
//        boolean result = instance.check_min(SD);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of check_max method, of class DashboardGUI.
     */
//    @Test
//    public void testCheck_max() {
//        System.out.println("check_max");
//        String SD = "Sunday";
//        DashboardGUI instance = new DashboardGUI();
//        boolean expResult = true;
//        boolean result = instance.check_max(SD);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of check_delete method, of class DashboardGUI.
     */
//    @Test
//    public void testCheck_delete() {
//        System.out.println("check_delete");
//        String id = "22112525";
//        String fname = "rasha";
//        String lname = "hatem";
//        DashboardGUI instance = new DashboardGUI();
//        boolean expResult = true;
//        boolean result = instance.check_delete(id, fname, lname);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of main method, of class DashboardGUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        DashboardGUI.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
