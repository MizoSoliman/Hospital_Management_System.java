/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazen
 */
public class RegisterGUITest {
    
    public RegisterGUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_register method, of class RegisterGUI.
     */
    @Test
//    public void testCheck_register() {
//        System.out.println("check_register");
//        String id = "22102525";
//        String Fname = "shaza";
//        String Lname = "hatem";
//        String ph = "01023232323";
//        String Address = "fym";
//        int Age = 23;
//        String Gender = "female";
//        String Password = "11111";
//        RegisterGUI instance = new RegisterGUI();
//        boolean expResult = false;
//        boolean result = instance.check_register(id, Fname, Lname, ph, Address, Age, Gender, Password);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
    
 public void testCheck_register() {
        System.out.println("check_register");
        String id = "22102525";
        String Fname = "shaza";
        String Lname = "hatem";
        String ph = "01023232323";
        String Address = "fym";
        int Age = 23;
        String Gender = "female";
        String Password = "11111";
        RegisterGUI instance = new RegisterGUI();
        boolean expResult = false;
        boolean result = instance.check_register(id, Fname, Lname, ph, Address, Age, Gender, Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class RegisterGUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        RegisterGUI.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
