/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Mazen
 */
public class LoginGUITest {
    
    public LoginGUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_login method, of class LoginGUI.
     */
    @Test
    //public void testCheck_login() {
       // System.out.println("check_login");
      //  String ID = "22102424";
      //  String Name = "nermeen";
      //  String pas = "1111";
//        LoginGUI instance = new LoginGUI();
//        boolean expResult = true;
//        boolean result = instance.check_login(ID, Name, pas);
//        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        // fail("The test case is a prototype.");
   // }
    
//     public void testCheck_login1() {
//        System.out.println("check_login");
//        String ID = "22002424";
//        String Name = "nermeen";
//        String pas = "1111";
//        LoginGUI instance = new LoginGUI();
//        boolean expResult = false;
//        boolean result = instance.check_login(ID, Name, pas);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        // fail("The test case is a prototype.");
//    }
    
    public void testCheck_login1() {
        System.out.println("check_login");
        String ID = "22002424";
        String Name = "ahmed";
        String pas = "1111";
        LoginGUI instance = new LoginGUI();
        boolean expResult = false;
        boolean result = instance.check_login(ID, Name, pas);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        // fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class LoginGUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        LoginGUI.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
