/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazen
 */
public class CheckingGUITest {
    
    public CheckingGUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_check_Btn method, of class CheckingGUI.
     */
//    @Test
//    public void testCheck_check_Btn() {
//        System.out.println("check_check_Btn");
//        String Fname = "mazin";
//        String Age = "22";
//        String ph = "01129073567";
//        CheckingGUI instance = new CheckingGUI();
//        boolean expResult = true;
//        boolean result = instance.check_check_Btn(Fname, Age, ph);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//       // fail("The test case is a prototype.");
//    }
    
//    @Test
//    public void testCheck_check_Btn() {
//        System.out.println("check_check_Btn");
//        String Fname = "mazin";
//        String Age = "44";
//        String ph = "01129073567";
//        CheckingGUI instance = new CheckingGUI();
//        boolean expResult = true;
//        boolean result = instance.check_check_Btn(Fname, Age, ph);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//       // fail("The test case is a prototype.");
//    }

    /**
     * Test of main method, of class CheckingGUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CheckingGUI.main(args);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
