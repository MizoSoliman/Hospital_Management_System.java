/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazen
 */
public class UpdateTest {
    
    public UpdateTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_update method, of class Update.
     */
//    @Test
//    public void testCheck_update() {
//        System.out.println("check_update");
//        String id = "22102727";
//        String oldpass = "5555";
//        String newpass = "4444";
//        Update instance = new Update();
//        boolean expResult = true;
//        boolean result = instance.check_update(id, oldpass, newpass);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//       // fail("The test case is a prototype.");
//    }

    
     @Test
    public void testCheck_update() {
        System.out.println("check_update");
        String id = "22102727";
        String oldpass = "56655";
        String newpass = "4444";
        Update instance = new Update();
        boolean expResult = false;
        boolean result = instance.check_update(id, oldpass, newpass);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    /**
     * Test of main method, of class Update.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Update.main(args);
        // TODO review the generated test code and remove the default call to fail.
       //  fail("The test case is a prototype.");
    }
    
}
