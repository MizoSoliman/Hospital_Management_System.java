package sproject;


public class Sproject {
    
    public static void main(String[] args) {
        // TODO code application logic here
        HomeGUI h = new HomeGUI() ;
        h.setVisible(true);
        
    }
    
}
