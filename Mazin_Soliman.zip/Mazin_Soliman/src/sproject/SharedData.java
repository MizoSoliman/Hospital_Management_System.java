/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sproject;

/**
 *
 * @author Mazen
 */
class SharedData {
    static String id = "" ;
    static String fname = "" ;
    static String lname = "" ;
    static String sday = "" ;
}
